package com.web.onlineshop.exception;

public class OnlineShopNotFoundException extends RuntimeException {
    public OnlineShopNotFoundException(String message) {
        super(message);
    }
}

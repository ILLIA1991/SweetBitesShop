INSERT INTO public.admin(id, username, password, role)
VALUES
    (1001, 'IlliaBelikau', 'passwordB', 'Admin'),
    (1002, 'MaksimKrymov', 'passwordM', 'Admin'),
    (1003, 'ElizaZyshchuk', 'passwordE', 'Admin');
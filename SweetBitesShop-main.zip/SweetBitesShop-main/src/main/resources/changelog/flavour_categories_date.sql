INSERT INTO public.flavour_categories(id, name, description)
VALUES
    (12, 'BANANA', 'Banana variety "Nendrum", Sweet, flavourful, with a slight sourness'),
    (13, 'STRAWBERRY', 'Strawberry variety "Alba" with a little sourness'),
    (14, 'CHERRY', 'Cherry variety "Actinia",The fruits are large, dark red, sweet and fragrant'),
    (15, 'CHOCOLATE', 'Milk chocolate: less than 35% cocoa, cocoa butter, sugar, milk powder');


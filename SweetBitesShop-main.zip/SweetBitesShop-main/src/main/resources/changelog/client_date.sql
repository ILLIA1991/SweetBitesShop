INSERT INTO public.client(id, name, surname, username, password, email, address, country, phone_number, role, blocked)
VALUES
    (3785, 'Illia', 'Belikau','IlliaBelikau','IB', 'ilasemcenkov1@gmail.com', 'Wroclaw, Hallera 99/13', 'Poland', '48730219815', 'Client', true),
    (3875, 'Maksim', 'Krymov','MaksimKrymov','MK', 'krymau@gmail.com', 'Wroclaw, Stawowa', 'Poland', '48986729826', 'Client', true),
    (3982, 'Anna', 'Nowak','AnnaNowak','AN', 'annanowak@gmail.com', 'Warsaw, Aleje Jerozolimskie 45', 'Poland', '48670451236', 'Client', true),
    (4021, 'Karolina', 'Kowalska','KarolinaKowalska','KK', 'karolinakowalska@gmail.com', 'Krakow, Florianska 28', 'Poland', '48502147698', 'Client', true);
INSERT INTO public.product(id, name, category_id, price)
VALUES
    (202, 'Cakes', 12, 4.32),
    (203, 'Cakes', 13, 8.25),
    (204, 'Cakes', 14, 6.18),
    (205, 'Cakes', 15, 5.11),
    (206, 'Macaroons', 12, 5.12),
    (207, 'Macaroons', 13, 9.45),
    (208, 'Macaroons', 14, 7.15),
    (209, 'Macaroons', 15, 5.28),
    (210, 'Eclairs', 12, 3.88),
    (211, 'Eclairs', 13, 7.18),
    (212, 'Eclairs', 14, 4.86),
    (213, 'Eclairs', 15, 5.33),
    (214, 'Donuts', 12, 4.56),
    (215, 'Donuts', 13, 9.76),
    (216, 'Donuts', 14, 6.16),
    (217, 'Donuts', 15, 5.77);
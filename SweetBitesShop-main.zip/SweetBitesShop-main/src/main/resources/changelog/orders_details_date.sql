INSERT INTO public.orders_details(id, orders_id, product_id, quantity, total_price)
VALUES
    (1, 2786, 203, 2, 16.50),
    (2, 2787, 208, 1, 7.15),
    (3, 2788, 204, 3, 18.54),
    (4, 2789, 214, 2, 10.66);

